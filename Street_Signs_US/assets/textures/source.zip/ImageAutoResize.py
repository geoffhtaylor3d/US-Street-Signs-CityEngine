import os, sys
from math import ceil
from PIL import Image, ImageStat

size = 128, 128


inFolder = r'C:/Users/geof7015/Documents/GitHub/Street_Signs_US/assets/textures/posts'
fileFormats = ['.jpg']
outFolder = r'C:/Users/geof7015/Documents/GitHub/Street_Signs_US/assets/textures/postsCompressed'

''' Max Width and height are only relative for a single side of the image. 
if one side of the image is larger then it will be scaled closer to the max values.'''
maxWidth = 300
maxHeight = 300


###############
# Definitions #
###############


def update_progress(progress):
    barLength = 10  # Modify this to change the length of the progress bar
    status = ""
    if isinstance(progress, int):
        progress = float(progress)
    if not isinstance(progress, float):
        progress = 0
        status = "error: progress var must be float\r\n"
    if progress < 0:
        progress = 0
        status = "Halt...\r\n"
    if progress >= 1:
        progress = 1
        status = "Done...\r\n"
    block = int(round(barLength*progress))
    text = "\rPercent Complete: [{0}] {1}% {2}".format("#"*block + "-"*(barLength-block), progress*100, status)
    sys.stdout.write(text)
    sys.stdout.flush()


def fileExt(inFile):
    ''' [0] returns fileName, [1] returns Extension '''
    filename, file_extension = os.path.splitext(inFile)
    return filename, file_extension.lower()


def genDirectory(inPath):
    if not os.path.exists(inPath):
        os.makedirs(inPath)


def delIfFileExists(inFile,outFolder):
    fullFilePath = os.path.join(outFolder, inFile)
    if os.path.exists(fullFilePath):
        try:
            os.remove(fullFilePath)
        except:
            print("Could not remove {0}".format(fullFilePath))
    else:
        pass


def imageColorType(pilImg):
    thumb_size = 40
    MSE_cutoff = 22
    adjust_color_bias = True
    bands = pilImg.getbands()
    if bands == ('R', 'G', 'B') or bands == ('R', 'G', 'B', 'A'):
        thumb = pilImg.resize((thumb_size, thumb_size))
        SSE, bias = 0, [0, 0, 0]
        if adjust_color_bias:
            bias = ImageStat.Stat(thumb).mean[:3]
            bias = [b - sum(bias)/3 for b in bias]
        for pixel in thumb.getdata():
            mu = sum(pixel)/3
            SSE += sum((pixel[i] - mu - bias[i])*(pixel[i] - mu - bias[i]) for i in [0, 1, 2])
        MSE = float(SSE)/(thumb_size*thumb_size)
        if MSE <= MSE_cutoff:
            return "grayscale"
        else:
            return "color"
    elif len(bands) == 1:
        return "bw"
    else:
        return "unknown"


def imageFitsDimensions(inPilImg, maxWidth, maxHeight):
    width, height = inPilImg.size
    if width <= maxWidth or height < maxHeight:
        return True
    else:
        return False


def imageScaling(inPilImg, maxWidth, maxHeight):
    width, height = inPilImg.size
    if height > width:
        scaleFactor = maxWidth / width
        return maxWidth, ceil(scaleFactor*height)
    elif width > height:
        scaleFactor = maxHeight / height
        return ceil(scaleFactor*width), maxHeight
    else:
        return maxWidth, maxHeight


################
# Begin Script #
################

genDirectory(outFolder)

imageFiles = [f for f in os.listdir(inFolder) if
              os.path.isfile(os.path.join(inFolder, f)) and fileExt(f)[1] in fileFormats]

count = 0
for imageFile in imageFiles:
    if count > 0:
        update_progress(count/len(imageFiles))
    delIfFileExists(imageFile, outFolder)
    inFile = os.path.join(inFolder, imageFile)
    outFile = os.path.join(outFolder, imageFile)
    count += 1
    try:
        im = Image.open(inFile)
        if imageColorType(im) != "color":
            im.convert('RGB')
        if imageFitsDimensions(im, maxWidth, maxHeight):
            im.save(outFile, "JPEG")
        else:
            imageScaling(im, maxWidth, maxHeight)
            im.thumbnail(size, Image.ANTIALIAS)
            im.save(outFile, "JPEG")
            outImg = im.resize((imageScaling(im, maxWidth, maxHeight)[0], imageScaling(im, maxWidth, maxHeight)[1]),
                               Image.ANTIALIAS)
            # outImg.save(outFile, quality=95)
            outImg.save(outFile, optimize=True, quality=95)
    except IOError:
        print("cannot resample image for" % imageFile)
update_progress(100)
